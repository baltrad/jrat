/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import org.w3c.dom.Document;


/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowPVOL52DataContainer extends RainbowVolume {

    /**
     * @param attribues
     */
    public RainbowPVOL52DataContainer(Document attribues) {
        super(attribues);
        // TODO Auto-generated constructor stub
    }

    public void printGeneralIfnormation() {
     // software version
        print("This is Rainbow volume version "
                + getAttributeValue("/volume", "version"));

        // type
        print("Data type:\t"
                + getAttributeValue("/volume/scan/slice/slicedata/rawdata",
                        "type"));
        // date
        print("Date:\t\t" + getAttributeValue("/volume/scan", "date") + " "
                + getAttributeValue("/volume/scan", "time"));
        // site name
        print("Site name:\t"
                + getAttributeValue("/volume/radarinfo/name", ""));
    }


    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getLon()
     */
    @Override
    public Double getLon() {
        String lon = "";
        lon = getRainbowAttributeValue("/volume/radarinfo", "lon");
        try {
            return Double.parseDouble(lon);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getLat()
     */
    @Override
    public Double getLat() {
        String lat = "";
        lat = getRainbowAttributeValue("/volume/radarinfo", "lat");
        try {
            return Double.parseDouble(lat);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getHeight()
     */
    @Override
    public Double getHeight() {
        String alt = "";
        alt = getRainbowAttributeValue("/volume/radarinfo", "alt");
        try {
            return Double.parseDouble(alt);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getSiteName()
     */
    @Override
    public String getSiteName() {
        return getRainbowAttributeValue("/volume/radarinfo/name", "");

    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getWavelength()
     */
    @Override
    public Double getWavelength() {
        String wl = "";
        wl = getRainbowAttributeValue("/volume/radarinfo/wavelen", "");
        try {
            return Double.parseDouble(wl);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getBeamwidth()
     */
    @Override
    public Double getBeamwidth() {
        String bw = "";
        bw = getRainbowAttributeValue("/volume/radarinfo/beamwidth", "");
        try {
            return Double.parseDouble(bw);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstH()
     */
    @Override
    public Double getRadConstH() {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstV()
     */
    @Override
    public Double getRadConstV() {
        // TODO Auto-generated method stub
        return null;
    }


    
}
