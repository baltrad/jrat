/**
 * (C) 2011 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.io.IOUtils;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import pl.imgw.jrat.data.parsers.FileParsingException;
import pl.imgw.util.Log;
import pl.imgw.util.LogManager;

import com.jcraft.jzlib.JZlib;
import com.jcraft.jzlib.ZStream;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowBlobHandler {

    private static Log log = LogManager.getLogger();
    
    private final char[] END = "<!-- END XML -->".toCharArray();
    private final char[] TAG = "<BLOB".toCharArray();
    
    protected static final Byte BITS_IN_BYTE = Byte.SIZE;
    protected static final Byte FLAG_ZERO = 0;
    
    private int offset = 0;
    private byte[] byteBuff;
    private Document doc;
    
    /**
     * @throws FileNotFoundException 
     * 
     */
    public RainbowBlobHandler(File rbfile) throws FileParsingException {
        // HashMap<Integer, BlobContainer> blobs = new HashMap<Integer,
        // BlobContainer>();

        FileInputStream fis;
        try {
            fis = new FileInputStream(rbfile);
            byteBuff = IOUtils.toByteArray(fis);
        } catch (FileNotFoundException e) {
            throw new FileParsingException(e.getMessage());
        } catch (IOException e) {
            throw new FileParsingException(e.getMessage());
        }
        if (!findXMLEnd(byteBuff))
            throw new FileParsingException("Parsing XML failed");
        
        doc = parseXML(byteBuff, 0, offset);
    }

    /**
     * @return the doc
     */
    public Document getDoc() {
        return doc;
    }

    public HashMap<Integer, RainbowBlobContainer> getBlobs() {
        
        HashMap<Integer, RainbowBlobContainer> blobs = new HashMap<Integer, RainbowBlobContainer>();
        
        boolean match = false;
        while(offset < byteBuff.length) {
            String xmlHeader = "";
            
            //looking for '<BLOB' tag
            for(int c = 0; c < TAG.length; c++) {
                if((char) byteBuff[offset + c] == TAG[c]) {
//                    System.out.println((char) b[offset + c]);
                    match = true;
                } else {
                    match = false;
                    break;
                }
            }
            if(match) {
                offset += TAG.length;
                //looking for closing tag
                while((char) byteBuff[++offset] != '>') {
                    xmlHeader += (char) byteBuff[offset];
                }
                RainbowBlobHeader header = new RainbowBlobHeader(xmlHeader);
                
                int blobsize = header.getSize();
                offset += 2; //skip closing sign and new line

                if(header.getCompression().matches("qt")) {
                    byte[] uncopressedSize = new byte[4];
                    for(int i = 0; i < 4; i++)
                        uncopressedSize[i] = byteBuff[offset++];
                    header.setSize(byteArray2Int(uncopressedSize));
                    blobsize -= 4; //skip 4 byte representing size
                }
                byte[] blobdata = Arrays.copyOfRange(byteBuff, offset, offset + blobsize);

                offset += blobsize;
                RainbowBlobContainer bc = new RainbowBlobContainer();
                if(header.getCompression().matches("qt")) {
                    bc.setCompressedArray(blobdata);
                } else {
                    bc.setDecompressedArray(blobdata);
                }
                bc.setDecompressedSize(header.getSize());
                blobs.put(header.getBlobid(), bc);
            } else {
                offset++;
            }
        }
        return blobs;
    }
    
    private boolean findXMLEnd(byte[] b) {
        boolean match;
        for (int i = 0; i < b.length; i++) {
            match = false;
            for (int c = 0; c < END.length; c++) {
                if ((char) b[i + c] == END[c]) {
                    match = true;
                } else {
                    match = false;
                    break;
                }
            }
            if(match) {
                offset = i;
                return true;
            }
        }
        return false;
    }
    
    public short firstAzimuth(byte[] input_buf, int len) {
        
        byte[] byte_buf = new byte[2 * len];

        // Inflate input stream
        ZStream defStream = new ZStream();
        defStream.next_in = input_buf;
        defStream.next_in_index = 0;
        defStream.next_out = byte_buf;
        defStream.next_out_index = 0;
        int err = defStream.inflateInit();
//        int a = 0;
        while (defStream.total_out < 2*len
                && defStream.total_in < input_buf.length) {
            defStream.avail_in = defStream.avail_out = 1;
            err = defStream.inflate(JZlib.Z_NO_FLUSH);
            if (err == JZlib.Z_STREAM_END)
                break;
//            a++;
            if(!isOK(defStream, err, "Inflation error")) {
                return 0;
            }
        }
        // System.out.println(a);
        err = defStream.inflateEnd();
        if(!isOK(defStream, err, "Inflation end error")) {
            return 0;
        }

        int azimuth = 2 * Short.MAX_VALUE;
        short firstAzimuth = 0;
        int a = 0;
        for (short i = 0; i < len; i++) {
            a = unsignedShortToInt(new byte[] { byte_buf[i * 2],
                    byte_buf[i * 2 + 1] });
            if (a < azimuth) {
                azimuth = a;
                firstAzimuth = i;
            }
        }
        
        return firstAzimuth;
    }
    
    /**
     * Check whether flag bits for given byte of 2D data are OK (e.g. all set to zero).
     * 
     * 
     * 
     * 
     * 
     * @param flagData - array with all flag bits
     * @param flagDepth - amount of flag bits that are relative to one data byte
     * @param byteNumber - number of byte in data2D collection
     * @return logical value: true if all (flagDepth) flags for given byte are OK (e.g. set to zero), false - if not
     */
    protected Boolean areFlagsOK(byte[] flagData, Short flagDepth, Integer byteNumber) {

        Integer bitNumber, startByte, startBitInByte, flagsBitsByteArrayLength, bitsUnusedFromEndOfArray, temp;
        byte[] flagsBitsByteArray;

        // number of starting bit in flagData
        bitNumber = byteNumber * flagDepth;
        // number of starting byte in flagData where the starting bit is located
        startByte = bitNumber / BITS_IN_BYTE;
        // number of bit in the starting byte in flagData where the starting bit is located
        startBitInByte = bitNumber % BITS_IN_BYTE;

        // reading as many bytes as it is needed to represent flag set as byte array
        flagsBitsByteArrayLength = ((startBitInByte + flagDepth - 1) / BITS_IN_BYTE) + 1;
        flagsBitsByteArray = new byte[flagsBitsByteArrayLength];
        for (int i = 0; i < flagsBitsByteArrayLength; i++)
            flagsBitsByteArray[i] = flagData[i + startByte];

        // how many bits are unused from the last bit of flag set to the bit at the end of byte array
        bitsUnusedFromEndOfArray = (flagsBitsByteArrayLength * BITS_IN_BYTE) - startBitInByte - flagDepth;

        // "clearing" first and last bytes from bits that do not represent flag set
        flagsBitsByteArray[0] <<= startBitInByte;
        temp = (flagsBitsByteArray[flagsBitsByteArrayLength - 1]) & 0xFF;
        if (flagsBitsByteArrayLength > 1)
            temp >>= bitsUnusedFromEndOfArray;
        else // flagsBitsByteArrayLength == 1
            temp >>= BITS_IN_BYTE - flagDepth;
        flagsBitsByteArray[flagsBitsByteArrayLength - 1] = temp.byteValue();

        // checking if all flags are ok
        for (int i = 0; i < flagsBitsByteArrayLength; i++)
            if (flagsBitsByteArray[i] != FLAG_ZERO)
                // if one part of analyzed flag set is not ok
                return false;
        // if all bits in flag set are ok
        return true;
    }
    
    /**
     * Method checks deflation errors
     * 
     * @param z
     *            Input ZStream
     * @param err
     *            Error code
     * @param msg
     *            Message
     * @param verbose
     *            Verbose mode toggle
     */
    private boolean isOK(ZStream z, int err, String msg) {
        if (err != JZlib.Z_OK) {
            if (z.msg != null) {
                msg += ": " + z.msg;
            }
            log.printMsg("Decompresing error: " + msg, Log.TYPE_ERROR, Log.MODE_VERBOSE);
            return false;
        }
        return true;
    }

    /**
     * Method converts 4 byte array value into integer value.
     * 
     * @param b
     *            Byte array
     * @return Integer
     */
    private int byteArray2Int(byte[] b) {
        int value = 0;
        for (int i = 0; i < 4; i++) {
            int shift = (4 - 1 - i) * 8;
            value += (b[i] & 0xFF) << shift;
        }
        return value;
    }

    /**
     * Converts a two byte array to an integer
     * @param b a byte array of length 2
     * @return an int representing the unsigned short
     */
    private int unsignedShortToInt(byte[] b) {
        int i = 0;
        i |= b[0] & 0xFF;
        i <<= 8;
        i |= b[1] & 0xFF;
        return i;
    }
    
    /**
     * Method parses RAINBOW metadata buffer
     * 
     * @param hdrBuff
     *            RAINBOW metadata buffer
     * @param verbose
     *            Verbose mode toggle
     * @return XML document object
     */
    private Document parseXML(byte[] fileBuff, int offset, int length) {

        Document doc = null;
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(fileBuff, offset, length);
            DOMParser parser = new DOMParser();
            InputSource is = new InputSource(bis);
            parser.parse(is);
            doc = parser.getDocument();
            
        } catch (Exception e) {
            e.printStackTrace();
            
        }
        return doc;
    }

}
