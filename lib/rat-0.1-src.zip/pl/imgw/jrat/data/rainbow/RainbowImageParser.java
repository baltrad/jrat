/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import pl.imgw.jrat.data.DataContainer;
import pl.imgw.jrat.data.parsers.FileParser;
import pl.imgw.util.Log;
import pl.imgw.util.LogManager;




/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowImageParser implements FileParser{

    private static Log log = LogManager.getLogger();
    
    private static final String BLOBID = "blobid";

//    private RainbowBlobHandler rp;
//    private HashMap<Integer, RainbowBlobContainer> blobs;
    private RainbowImageDataContainer data = null;
    
    private static final String PRODUCT = "product";
    private static final String ROWS = "rows";
    private static final String COLUMNS = "columns";
    private static final String DEPTH = "depth";
    private static final String DATAMAP = "datamap";
    private static final String FLAGMAP = "flagmap";

    private static final String RADARPICTURE = "/product/data/radarpicture";

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.FileParser#isValid(java.io.File)
     */
    @Override
    public boolean isValid(File file) {
        try {
            FileInputStream fstream = new FileInputStream(file);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine = br.readLine();
            in.close();
            if (!strLine.contains(PRODUCT)) {
                return false;
            }
//            if (strLine.contains("version=\"5.3"))
//                return true;
            return true;
        } catch (Exception e) {// Catch exception if any
            return false;
        }
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.parsers.FileParser#initialize(java.io.File)
     */
    @Override
    public boolean parse(File file) {
        
        data = null;
        if (file == null) {
            return false;
        }
        
        if (!isValid(file)) {
            log.printMsg(
                    "'" + file.getName()
                            + "' is not a valid RAINBOW image 5.3 format",
                    Log.TYPE_WARNING, Log.MODE_VERBOSE);

            return false;
        }
        HashSet<Param> params;
        
        
        params = setParams(file);
        if (params.isEmpty())
            return false;

        
        RainbowBlobHandler blobHandler = new RainbowBlobHandler(file);
        HashMap<Integer, RainbowBlobContainer> blobs = blobHandler.getBlobs();
        
        if (blobs == null || blobs.isEmpty()) {
            log.printMsg(
                    "'" + file.getName()
                            + "': failed to read blob data",
                    Log.TYPE_WARNING, Log.MODE_VERBOSE);
            return false;
        }
        
        data = new RainbowImageDataContainer(blobHandler.getDoc());
        
        RainbowImageArray array = new RainbowImageArray();
        
        Iterator<Param> itr = params.iterator();
        while (itr.hasNext()) {
            Param p = itr.next();
//            byte[][] infDataBuff = rp.inflateDataSection(blobs.get(p.blobid),
//                    p.sizeX, p.sizeY, p.depth);
            blobs.get(p.blobid).setDepth(p.depth);
            if(p.type == DATAMAP) {
                array.setBlobData(blobs.get(p.blobid));
                array.setRows(p.rows);
                array.setColumns(p.columns);
            }
            else if(p.type == FLAGMAP) {
                array.setBlobFlag(blobs.get(p.blobid));
                array.setFlagRows(p.rows);
                array.setFlagColumns(p.columns);
            }
            
        }
        
        String min, max;
        double mind, maxd;
        
        try {
            min = data.getRainbowAttributeValue(RADARPICTURE, "min");
            max = data.getRainbowAttributeValue(RADARPICTURE, "max");
            mind = Double.parseDouble(min);
            maxd = Double.parseDouble(max);
            maxd = (maxd - mind) / 254;
//            mind -= 0.5;

        } catch (NumberFormatException e) {
            return false;
        }
        
        array.setGain(maxd);
        array.setOffset(mind);
        data.getArrayList().put("", array);
            
//        System.out.println("ilosc blobow: " + getProduct().getArrayList().size());
        log.printMsg("Rainbow image file: " + file.getName() + " initialized",
                Log.TYPE_NORMAL, Log.MODE_VERBOSE);
        return true;
    }

    /**
     * @param file
     * @return
     */
    private HashSet<Param> setParams(File file) {
        HashSet<Param> params = new HashSet<Param>();
        try {
            FileInputStream fileInputStream;
            fileInputStream = new FileInputStream(file);
            XMLStreamReader xml = XMLInputFactory.newInstance()
                    .createXMLStreamReader(fileInputStream);
            String type = "";

            while (xml.hasNext()) {

                int sizeX = 0, sizeY = 0, depth = 0;
                int blobid = -1;

                int event = xml.next();

                if (event == XMLStreamConstants.END_ELEMENT) {

                    if (xml.getLocalName().matches(PRODUCT)) {
                        break;
                    }
                }
                if (event == XMLStreamConstants.START_ELEMENT) {
                    String element = xml.getLocalName();
                    // System.out.println("1: " + element);
                    boolean found = false;

                    if (element.matches(FLAGMAP)) {
                        type = FLAGMAP;
                        // System.out.println("2: " + type);
                        found = true;
                    } else if (element.matches(DATAMAP)) {
                        type = DATAMAP;
                        // System.out.println("2: " + type);
                        found = true;
                    }

                    if (found) {
                        for (int i = 0; i < xml.getAttributeCount(); i++) {
                            if (xml.getAttributeLocalName(i).matches(BLOBID)) {
                                try {
                                    blobid = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                    // System.out.println("blobid: " + blobid);
                                } catch (NumberFormatException e) {
                                    
                                }
                            } else if (xml.getAttributeLocalName(i).matches(
                                    ROWS)) {
                                try {
                                    sizeX = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                    // System.out.println("sizeX: " + sizeX);
                                } catch (NumberFormatException e) {
                                    
                                }
                            } else if (xml.getAttributeLocalName(i).matches(
                                    COLUMNS)) {
                                try {
                                    sizeY = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                    // System.out.println("sizeY: " + sizeY);
                                } catch (NumberFormatException e) {
                                    
                                }
                            } else if (xml.getAttributeLocalName(i).matches(
                                    DEPTH)) {
                                try {
                                    depth = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                } catch (NumberFormatException e) {
                                    
                                }
                            }
                        }

                        if (sizeX != 0 && blobid != -1) {
                            Param param = new Param();
                            param.depth = depth;
                            param.rows = sizeX;
                            param.columns = sizeY;
                            param.blobid = blobid;
                            param.type = type;
                            params.add(param);

                        }

                    }

                }
            }
        
        fileInputStream.close();
        xml.close();
        } catch (FileNotFoundException e) {
            log.printMsg(
                    "File " + file.getName() + " was not found", Log.TYPE_ERROR, Log.MODE_VERBOSE);
        } catch (XMLStreamException e) {
            log.printMsg(
                    "File " + file.getName() + " is not a XML format", Log.TYPE_ERROR, Log.MODE_VERBOSE);
        } catch (FactoryConfigurationError e) {
            log.printMsg(
                    "File " + file.getName() + " cannot be initialized", Log.TYPE_ERROR, Log.MODE_VERBOSE);
        } catch (IOException e) {
            log.printMsg(
                    "File " + file.getName() + " cannot be initialized", Log.TYPE_ERROR, Log.MODE_VERBOSE);
        }
        return params;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.parsers.FileParser#getProduct()
     */
    @Override
    public DataContainer getData() {
        return data;
    }
    
    class Param{
        int rows;
        int columns;
        int depth;
        int blobid;
        String type;
    }
    
}
