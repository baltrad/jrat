/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;

import pl.imgw.jrat.data.ScanContainer;
import pl.imgw.jrat.data.PolarData;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public abstract class RainbowVolume extends XMLDataContainer implements PolarData {

    /**
     * @param attribues
     */
    public RainbowVolume(Document attribues) {
        super(attribues);
        // TODO Auto-generated constructor stub
    }

    protected Map<Double, ScanContainer> scans = new HashMap<Double, ScanContainer>();

    /**
     * 
     * Receiving attribute value from product in given path and if necessary
     * also given name. When the value is store as an attribute it is necessary
     * to point exact attribute in the node by this name e.g.</br></br>
     * 
     * 
     * {@code <book type="fiction"/>} in this case getAttributeValue("/book",
     * "type") will return "fiction" </br></br>
     * 
     * If there are more then one node with the same name in the path, you can
     * specify the correct one by pointing its argument name and value using ':'
     * and '=' e.g. </br></br>
     * 
     * {@code <slice refid="0">} </br> {@code <posangle>0.5</posangle>}</br> and
     * the argument for the method will be:</br></br>
     * 
     * {@code getAttributeValue("/slice:refid=0/posangle", "")}
     * 
     * @param path
     *            e.g. /book/author
     * @param name
     *            use empty string if not needed
     * @return empty string if attribute not find
     */
    public String getRainbowAttributeValue(String path, String name) {
        return (String) getAttributeValue(path, name);
    }
    
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getPulsewidth()
     */
    @Override
    public Double getPulsewidth() {
        // TODO Auto-generated method stub
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getScan(double)
     */
    @Override
    public ScanContainer getScan(final double elevation) {

        if(scans.containsKey(elevation))
            return scans.get(elevation);
        
        ScanContainer scan;
        try {
            scan = new RainbowPolarScan(this, elevation);
        } catch (Exception e) {
            return null;
        }
        
        scans.put(elevation, scan);
        return scan;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getTime()
     */
    @Override
    public Date getTime() {
        try {
            String date = getRainbowAttributeValue("/volume/scan", "date")
                    .replaceAll("-", "");
            String time = getRainbowAttributeValue("/volume/scan", "time")
                    .replaceAll(":", "");
            return formatMinutePrecision.parse(date
                    + time.substring(0, time.length() - 2));
        } catch (Exception e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getTimeSec()
     */
    @Override
    public Date getTimeSec() {
        try {
            String date = getRainbowAttributeValue("/volume/scan", "date")
                    .replaceAll("-", "");
            String time = getRainbowAttributeValue("/volume/scan", "time")
                    .replaceAll(":", "");
            return formatSecondPrecision.parse(date
                    + time.substring(0, time.length()));
        } catch (Exception e) {
            return null;
        }
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.VolumeContainer#getVolId()
     */
    @Override
    public String getVolId() {
        String id = "'Rb5 vol ";
        id += getSiteName();
        id += " ";
        id += formatMinutePrecision.format(getTime());
        id += "'";
        return id;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.VolumeContainer#getAllScans()
     */
    @Override
    public List<ScanContainer> getAllScans() {

        int size = getArrayList().size();

        if (scans.size() < size) {

            for (int i = 0; i < size; i++) {
                String posangle = getRainbowAttributeValue(
                        "/volume/scan/slice:refid=" + i + "/posangle", "");
                double ele = Double.parseDouble(posangle);
                getScan(ele);
            }
        }
        return new ArrayList<ScanContainer>(scans.values());
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstH()
     */
    @Override
    public Double getRadConstH() {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstV()
     */
    @Override
    public Double getRadConstV() {
        // TODO Auto-generated method stub
        return null;
    }

}
