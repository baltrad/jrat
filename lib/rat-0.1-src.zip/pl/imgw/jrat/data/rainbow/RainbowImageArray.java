/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import pl.imgw.jrat.data.OutOfBoundsException;
import pl.imgw.jrat.data.UnsignedByteArray;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowImageArray extends UnsignedByteArray {

    protected RainbowBlobContainer blobdata;
    protected RainbowBlobContainer blobflag;
    protected double offset = 0;
    protected double gain = 0;
    
    protected boolean[][] flags;
    private int flagXSize;
    private int flagYSize;
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.UnsignedByteArray#getRawBytePoint(int, int)
     */
    @Override
    public byte getRawBytePoint(int x, int y) {
        setData();
        return super.getRawBytePoint(x, y);
    }
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.UnsignedByteArray#getRawIntPoint(int, int)
     */
    @Override
    public short getRawIntPoint(int x, int y) {
        setData();
        return super.getRawIntPoint(x, y);
    }
    
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.UnsignedByteArray#getPoint(int, int)
     */
    @Override
    public double getPoint(int x, int y) {
        setData();
        return super.getPoint(x, y);
        
    }
    
    private boolean setData() {
        
        if(data != null) 
            return true;
        
        byte[] datamap = blobdata.getDecompressed();
        int dataDepth = blobdata.getDepth();
        if (dataDepth == 8) {
            data = RainbowDataFiller.getData8Depth(datamap, sizeX, sizeY);
        } else {
            return false;
        }
        
        return true;
        
    }
    
    public boolean getFlag(int x, int y) throws OutOfBoundsException{
        setFlags();
        if(transposed) {
            int tmp = x;
            x = y;
            y = tmp;
        }
        if (x < 0 || y < 0 || x >= flagXSize || y >= flagYSize) {
            throw new OutOfBoundsException();
        }
        return flags[x][y];
    }
    
    private boolean setFlags() {
        if (flags != null)
            return true;

        byte[] flagmap = blobflag.getDecompressed();
        int flagDepth = blobflag.getDepth();
        if (flagDepth == 1) {
            flags = RainbowDataFiller.getData1Depth(flagmap, flagXSize,
                    flagYSize);
        } else if (flagDepth == 2) {
            flags = RainbowDataFiller.getData2Depth(flagmap, flagXSize,
                    flagYSize);
        } else
            return false;

        return true;
    }
    
    public void setRows(int rows) {
        sizeX = rows;
    }
    
    public void setColumns(int columns) {
        sizeY = columns;
    }

    /**
     * @param flagRows the flagXSize to set
     */
    public void setFlagRows(int flagRows) {
        this.flagXSize = flagRows;
    }

    /**
     * @param flagColumns the flagYSize to set
     */
    public void setFlagColumns(int flagColumns) {
        this.flagYSize = flagColumns;
    }
    
    /**
     * @param blobdata the blobdata to set
     */
    public void setBlobData(RainbowBlobContainer blobdata) {
        this.blobdata = blobdata;
    }


    /**
     * @param blobflag the blobray to set
     */
    public void setBlobFlag(RainbowBlobContainer blobflag) {
        this.blobflag = blobflag;
    }

    
}
