/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import org.w3c.dom.Document;


/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowPVOL53DataContainer extends RainbowVolume {

    /**
     * @param attribues
     */
    public RainbowPVOL53DataContainer(Document attribues) {
        super(attribues);
    }

    public void printGeneralIfnormation() {
        
     // software version
        print("This is Rainbow volume version "
                + getAttributeValue("/volume", "version"));

        // type
        print("Data type:\t"
                + getAttributeValue("/volume/scan/slice/slicedata/rawdata",
                        "type"));
        // date
        print("Date:\t\t" + getAttributeValue("/volume/scan", "date") + " "
                + getAttributeValue("/volume/scan", "time"));
        // site name
        print("Site name:\t"
                + getAttributeValue("/volume/sensorinfo", "name"));
        
    }
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getLon()
     */
    @Override
    public Double getLon() {
        String lon = "";

        lon = getRainbowAttributeValue("/volume/sensorinfo/lon", "");

        try {
            return Double.parseDouble(lon);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getLat()
     */
    @Override
    public Double getLat() {
        String lat = "";
        lat = getRainbowAttributeValue("/volume/sensorinfo/lat", "");
        try {
            return Double.parseDouble(lat);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getHeight()
     */
    @Override
    public Double getHeight() {
        String alt = "";
            alt = getRainbowAttributeValue("/volume/sensorinfo/alt", "");
        try {
            return Double.parseDouble(alt);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getSiteName()
     */
    @Override
    public String getSiteName() {
        return getRainbowAttributeValue("/volume/sensorinfo", "name");
    }
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getWavelength()
     */
    @Override
    public Double getWavelength() {
        String wl = "";
        wl = getRainbowAttributeValue("/volume/sensorinfo/wavelen", "");
        try {
            return Double.parseDouble(wl);
        } catch (NumberFormatException e) {
            return null;
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getBeamwidth()
     */
    @Override
    public Double getBeamwidth() {
        String bw = "";
        bw = getRainbowAttributeValue("/volume/sensorinfo/beamwidth", "");
        try {
            return Double.parseDouble(bw);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstH()
     */
    @Override
    public Double getRadConstH() {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstV()
     */
    @Override
    public Double getRadConstV() {
        // TODO Auto-generated method stub
        return null;
    }
    
}
