/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import pl.imgw.jrat.data.ArrayData;
import pl.imgw.jrat.data.AttributeNotFoundException;
import pl.imgw.jrat.data.DataContainer;
import pl.imgw.util.Log;
import pl.imgw.util.LogManager;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public abstract class XMLDataContainer implements DataContainer {

    private static Log log = LogManager.getLogger();
    
    protected Map<String, ArrayData> arrayList = new HashMap<String, ArrayData>();

    protected Document attributes;

    public XMLDataContainer(Document attributes) {
        this.attributes = attributes;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.ProductDataContainer#setArrayList(java.util.List)
     */
    @Override
    public void setArrayList(Map<String, ArrayData> arrayList) {
        this.arrayList = arrayList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.ProductDataContainer#getArrayList()
     */
    @Override
    public Map<String, ArrayData> getArrayList() {
        return arrayList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.ProductDataContainer#getArray(int)
     */
    @Override
    public ArrayData getArray(String name) {
        return arrayList.get(name);
    }

    
    /**
     * @param path containing all tag names slash separated ('/')
     * @param name attribute name, use empty string if no attribute
     * 
     * @return value as a string, empty string if not found
     */
    @Override
    public Object getAttributeValue(String path, String name) {

        if (attributes == null) {
            throw new AttributeNotFoundException("Attributes not initialized");
        }

        try {
            if (path.startsWith("/"))
                path = path.substring(1);

            String[] parents = path.split("/");

            Node element = attributes.getDocumentElement();
            if (parents.length > 1) {
                for (int i = 1; i < parents.length; i++) {
                    String argname = "";
                    String argval = "";
                    if (parents[i].contains(":") && parents[i].contains("=")) {
                        argname = parents[i].split(":")[1].split("=")[0];
                        argval = parents[i].split(":")[1].split("=")[1];
                        parents[i] = parents[i].split(":")[0];
                    }
                    element = findNode(element, parents[i], argname, argval);
                    if (element == null)
                        throw new AttributeNotFoundException(getErrMsg(path, name));
                }
            }

            if (name.isEmpty()) {
                String value = element.getFirstChild().getNodeValue();
                if (value != null)
                    return value;
                else
                    throw new AttributeNotFoundException(getErrMsg(path, name));
            } else {
                String value = element.getAttributes().getNamedItem(name)
                        .getNodeValue();
                if (value != null)
                    return value;
                else
                    throw new AttributeNotFoundException(getErrMsg(path, name));
            }
        } catch (DOMException e) {
            log.printMsg(
                    getErrMsg(path, name), Log.TYPE_ERROR, Log.MODE_VERBOSE);

        } catch (NullPointerException e) {
            log.printMsg(
                    getErrMsg(path, name), Log.TYPE_WARNING, Log.MODE_VERBOSE);
        }
        
        throw new AttributeNotFoundException(getErrMsg(path, name));
    }
    
    private String getErrMsg(String path, String name) {
        return "Attribute '" + name + "' in path '" + path + " not found";
    }

    protected Node findNode(Node element, String name, String argname,
            String argvalue) {
        for (Node child = element.getFirstChild(); child != null; child = child
                .getNextSibling()) {
            // System.out.println(child.getNodeName());
            if (child.getNodeName().matches(name)) {
                if (!argname.isEmpty() && !argvalue.isEmpty()) {

                    NamedNodeMap atrs = child.getAttributes();
                    for (int i = 0; i < atrs.getLength(); i++) {
                        if (atrs.item(i).getNodeName().matches(argname)
                                && atrs.item(i).getNodeValue()
                                        .matches(argvalue)) {
                            return child;
                        }

                    }

                } else
                    return child;
            }
        }
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.SimpleContainer#printAllAttributes()
     */
    @Override
    public void printAllAttributes() {
        try {
            // System.out.println(getAttributeValue("/product", "version"));

            Transformer transformer;
            transformer = TransformerFactory.newInstance().newTransformer();
            Source source = new DOMSource(attributes);
            Result output = new StreamResult(System.out);
            transformer.transform(source, output);
            System.out.print("\n");

        } catch (TransformerConfigurationException e) {
            log.printMsg("Parsing XML text error", Log.TYPE_ERROR, Log.MODE_VERBOSE);
        } catch (TransformerFactoryConfigurationError e) {
            log.printMsg("Parsing XML text error", Log.TYPE_ERROR, Log.MODE_VERBOSE);
        } catch (TransformerException e) {
            log.printMsg("Parsing XML text error", Log.TYPE_ERROR, Log.MODE_VERBOSE);
        }
    }

    protected void print(String s) {
        System.out.println(s);
    }


}
