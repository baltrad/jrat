/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import org.w3c.dom.Document;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowImageDataContainer extends XMLDataContainer {
    /**
     * @param attribues
     */
    public RainbowImageDataContainer(Document attribues) {
        super(attribues);
    }

    /**
     * 
     * Receiving attribute value from product in given path and if necessary
     * also given name. When the value is store as an attribute it is necessary
     * to point exact attribute in the node by this name e.g.</br></br>
     * 
     * 
     * {@code <book type="fiction"/>} in this case getAttributeValue("/book",
     * "type") will return "fiction" </br></br>
     * 
     * If there are more then one node with the same name in the path, you can
     * specify the correct one by pointing its argument name and value using ':'
     * and '=' e.g. </br></br>
     * 
     * {@code <slice refid="0">} </br> {@code <posangle>0.5</posangle>}</br> and
     * the argument for the method will be:</br></br>
     * 
     * {@code getAttributeValue("/slice:refid=0/posangle", "")}
     * 
     * @param path
     *            e.g. /book/author
     * @param name
     *            use empty string if not needed
     * @return empty string if attribute not find
     */
    public String getRainbowAttributeValue(String path, String name) {
        return (String) getAttributeValue(path, name);
    }
    
    public void printGeneralIfnormation() {
        // software version
        print("This is Rainbow image version "
                + getAttributeValue("/product", "version"));

        // type
        print("Product type:\t" + getAttributeValue("/product", "name"));
        print("Data type:\t" + getAttributeValue("/product", "datatype"));
        // date
        print("Date:\t\t" + getAttributeValue("/product/data", "date") + " "
                + getAttributeValue("/product/data", "time"));
        // site name
        print("Site name:\t"
                + getAttributeValue("/product/data/sensorinfo", "name"));
    }
}
