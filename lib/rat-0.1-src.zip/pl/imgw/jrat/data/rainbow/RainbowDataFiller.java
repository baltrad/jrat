/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowDataFiller {

    protected static final Byte BITS_IN_BYTE = Byte.SIZE;
    protected static final Byte FLAG_ZERO = 0;
    
    public static byte[][] getData(byte[] data, int sizeX, int sizeY, int depth){
        byte[][] output = new byte[sizeX][sizeY];
        int count = 0;
        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                count = y * sizeX + x;
                if (depth == 8) {
                    output[x][y] = data[count];
                }
                else if (depth == 1) {
                    if (isBitSet(data[count / 8], count % 8))
                        output[x][y] = 1;
                } else if (depth == 2) {
                    if (!areFlagsOK(data, (short)2, count))
                        output[x][y] = 1;
//                    if (isBitSet(byte_buf[count / 4], 2 * (count % 4) + 1))
//                        output_buf[x][y] = 1;
                }
//                count++;
            }
        }
        
        return output;
    }
    
    public static byte[][] getData8Depth(byte[] data, int sizeX, int sizeY) {
        byte[][] output = new byte[sizeX][sizeY];
        int count = 0;
        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                count = y * sizeX + x;
                output[x][y] = data[count];

            }
        }
        return output;
    }

    public static boolean[][] getData1Depth(byte[] data, int sizeX, int sizeY){
        boolean[][] output = new boolean[sizeX][sizeY];
        int count = 0;
        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                count = y * sizeX + x;
                if (!isBitSet(data[count / 8], count % 8))
                    output[x][y] = true;

            }
        }
        return output;
    }
    
    public static boolean[][] getData2Depth(byte[] data, int sizeX, int sizeY){
        boolean[][] output = new boolean[sizeX][sizeY];
        int count = 0;
        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                count = y * sizeX + x;
                if (areFlagsOK(data, (short)2, count))
                    output[x][y] = true;

            }
        }
        return output;
    }
    
    private static Boolean isBitSet(byte b, int bit) {
        return (b & (1 << (8 - bit ))) != 0;
    }
    
    /**
     * Check whether flag bits for given byte of 2D data are OK (e.g. all set to zero).
     * 
     * 
     * 
     * 
     * 
     * @param flagData - array with all flag bits
     * @param flagDepth - amount of flag bits that are relative to one data byte
     * @param byteNumber - number of byte in data2D collection
     * @return logical value: true if all (flagDepth) flags for given byte are OK (e.g. set to zero), false - if not
     */
    protected static Boolean areFlagsOK(byte[] flagData, Short flagDepth, Integer byteNumber) {

        Integer bitNumber, startByte, startBitInByte, flagsBitsByteArrayLength, bitsUnusedFromEndOfArray, temp;
        byte[] flagsBitsByteArray;

        // number of starting bit in flagData
        bitNumber = byteNumber * flagDepth;
        // number of starting byte in flagData where the starting bit is located
        startByte = bitNumber / BITS_IN_BYTE;
        // number of bit in the starting byte in flagData where the starting bit is located
        startBitInByte = bitNumber % BITS_IN_BYTE;

        // reading as many bytes as it is needed to represent flag set as byte array
        flagsBitsByteArrayLength = ((startBitInByte + flagDepth - 1) / BITS_IN_BYTE) + 1;
        flagsBitsByteArray = new byte[flagsBitsByteArrayLength];
        for (int i = 0; i < flagsBitsByteArrayLength; i++)
            flagsBitsByteArray[i] = flagData[i + startByte];

        // how many bits are unused from the last bit of flag set to the bit at the end of byte array
        bitsUnusedFromEndOfArray = (flagsBitsByteArrayLength * BITS_IN_BYTE) - startBitInByte - flagDepth;

        // "clearing" first and last bytes from bits that do not represent flag set
        flagsBitsByteArray[0] <<= startBitInByte;
        temp = (flagsBitsByteArray[flagsBitsByteArrayLength - 1]) & 0xFF;
        if (flagsBitsByteArrayLength > 1)
            temp >>= bitsUnusedFromEndOfArray;
        else // flagsBitsByteArrayLength == 1
            temp >>= BITS_IN_BYTE - flagDepth;
        flagsBitsByteArray[flagsBitsByteArrayLength - 1] = temp.byteValue();

        // checking if all flags are ok
//FIXME FOR DEBUG ONLY - DELETE BELOW
        for (int i = 0; i < flagsBitsByteArrayLength; i++)
            if (flagsBitsByteArray[i] != FLAG_ZERO)
                // if one part of analyzed flag set is not ok
                //TODO might be that it is guilty only when the "correct" flag is zero flag
                return false;
        // if all bits in flag set are ok
        return true;
    }
    
}
