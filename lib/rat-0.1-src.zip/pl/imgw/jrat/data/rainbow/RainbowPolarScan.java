/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import java.awt.geom.Point2D;
import java.util.Date;

import pl.imgw.jrat.data.ArrayData;
import pl.imgw.jrat.data.PolarData;
import pl.imgw.jrat.data.ScanContainer;
import pl.imgw.util.Log;
import pl.imgw.util.LogManager;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowPolarScan implements ScanContainer {

    private static Log log = LogManager.getLogger();

    private RainbowVolume voldata;
    private double elevation;
    private String path;

    /**
     * 
     */
    public RainbowPolarScan(RainbowVolume vol, double elevation)
            throws Exception {
        this.voldata = vol;
        this.elevation = elevation;
        path = getSlicedataPath(vol, elevation);
        if (path == null)
            throw new Exception("No elevation in the volume");

    }

    private String getSlicedataPath(RainbowVolume xmlData, double elevation) {
        int size = xmlData.getArrayList().size();
        int refid = -1;
        for (int i = 0; i < size; i++) {
            String posangle = xmlData.getRainbowAttributeValue(
                    "/volume/scan/slice:refid=" + i + "/posangle", "");
            if (posangle.matches(Double.toString(elevation))) {
                refid = i;
                break;
            }
        }

        if (refid != -1) {
            return "/volume/scan/slice:refid=" + refid + "/slicedata";
        }

        log.printMsg("Elevation " + elevation + " not found ",
                Log.TYPE_WARNING, Log.MODE_VERBOSE);

        return null;
    }

    @Override
    public Date getStartTime() {
        try {
            String date = voldata.getRainbowAttributeValue(path, "date")
                    .replaceAll("-", "");
            String time = voldata.getRainbowAttributeValue(path, "time")
                    .replaceAll(":", "");
            return PolarData.formatSecondPrecision.parse(date
                    + time.substring(0, time.length()));
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public double getRScale() {
        String rscale = voldata.getRainbowAttributeValue(
                "/volume/scan/pargroup/rangestep", "");
        try {
            double range = Double.parseDouble(rscale);
            return range * 1000;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    public int getNRays() {
        String rays = voldata.getRainbowAttributeValue(path + "/rawdata",
                "rays");
        try {
            return Integer.parseInt(rays);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    public int getNBins() {
        String bins = voldata.getRainbowAttributeValue(path + "/rawdata",
                "bins");
        try {
            return Integer.parseInt(bins);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    public double getElevation() {
        return elevation;
    }

    @Override
    public ArrayData getArray() {
        String blobid = voldata.getRainbowAttributeValue(path + "/rawdata",
                "blobid");

        if (blobid.isEmpty())
            return null;

        return voldata.getArray(blobid);
    }

    @Override
    public Point2D.Double getCoordinates() {
        return new Point2D.Double(voldata.getLon(), voldata.getLat());
    }

    @Override
    public double getRPM() {
        String ant = voldata.getRainbowAttributeValue(
                "/volume/scan/pargroup/antspeed", "");
        try {
            return 60 / (360 / Double.parseDouble(ant));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    public double getOffset() {

        return ((RainbowScanArray) getArray()).getOffset();
    }

    @Override
    public double getGain() {

        return ((RainbowScanArray) getArray()).getGain();
    }

    @Override
    public double getNodata() {
        return 0;
    }

    @Override
    public double getUndetect() {
        return 0;
    }

}
