/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import pl.imgw.jrat.data.DataContainer;
import pl.imgw.jrat.data.PolarData;
import pl.imgw.jrat.data.parsers.VolumeParser;
import pl.imgw.util.Log;
import pl.imgw.util.LogManager;

/**
 * 
 * Works with rainbow volumes versions 5.2x and 5.3x
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class RainbowVolumeParser implements VolumeParser {

    private static Log log = LogManager.getLogger();
    
    private static final String SLICEDATA_RAWDATA = "/slicedata/rawdata";
    private static final String SLICE_REFID = "/volume/scan/slice:refid=";

    private static final String BLOBID = "blobid";

//    private RainbowBlobHandler rp;
//    private HashMap<Integer, RainbowBlobContainer> blobs;
    private RainbowVolume data = null;

    private static final String VOLUME = "volume";
    private static final String SLICE = "slice";
    private static final String RAYS = "rays";
    private static final String BINS = "bins";
    private static final String DEPTH = "depth";
    private static final String RAWDATA = "rawdata";
    private static final String RAYINFO = "rayinfo";
    
    private int version = 0;
    private static final int RB52 = 2;
    private static final int RB53 = 3;
    
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.parsers.FileParser#isValid(java.io.File)
     */
    @Override
    public boolean isValid(File file) {
        try {
            FileInputStream fstream = new FileInputStream(file);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine = null;
            do {
                strLine = br.readLine();
                if (strLine == null)
                    break;
            } while (!strLine.contains(VOLUME));
            in.close();
            
            if (strLine.contains("version=\"5.3")) {
                version = RB53;
                return true;
            }
            if (strLine.contains("version=\"5.2")) {
                version = RB52;
                return true;
            }
            return false;
        } catch (Exception e) {// Catch exception if any
            return false;
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.parsers.FileParser#initialize(java.io.File)
     */
    @Override
    public boolean parse(File file) {

        if (file == null) {
            return false;
        }
        
        if (!isValid(file)) {
            log.printMsg(
                    "'" + file.getName()
                            + "' is not a valid RAINBOW 5.x volume format",
                    Log.TYPE_WARNING, Log.MODE_VERBOSE);
            return false;
        }
        
        HashMap<Integer, Param> params = setParams(file);
        
        if (params.isEmpty())
            return false;

        RainbowBlobHandler rp = new RainbowBlobHandler(file);
        HashMap<Integer, RainbowBlobContainer> blobs = rp.getBlobs();
        
        if (blobs == null || blobs.isEmpty()) {
            log.printMsg(
                    "[1]'" + file.getName() + "' failed to parse the file",
                    Log.TYPE_WARNING, Log.MODE_VERBOSE);
        }

        if (version == RB53)
            data = new RainbowPVOL53DataContainer(rp.getDoc());
        else if (version == RB52)
            data = new RainbowPVOL52DataContainer(rp.getDoc());
        else
            return false;
        
        fillParameters(params, blobs);

        log.printMsg("Rainbow volume file: " + file.getName() + " initialized",
                Log.TYPE_NORMAL, Log.MODE_VERBOSE);
        
        return true;
    }

    /**
     * @param params
     */
    private void fillParameters(HashMap<Integer, Param> params,
            HashMap<Integer, RainbowBlobContainer> blobs) {
        String min, max;
        double mind, maxd;

        Iterator<Integer> itr = params.keySet().iterator();
        while (itr.hasNext()) {

            int refid = itr.next();
            try {
                min = data.getRainbowAttributeValue(SLICE_REFID + refid
                        + SLICEDATA_RAWDATA, "min");
                max = data.getRainbowAttributeValue(SLICE_REFID + refid
                        + SLICEDATA_RAWDATA, "max");
                mind = Double.parseDouble(min);
                maxd = Double.parseDouble(max);
                maxd = (maxd - mind) / 254;
                mind -= 0.5;

            } catch (NumberFormatException e) {
                continue;
            }
            Param param = params.get(refid);
            RainbowScanArray array = new RainbowScanArray();
            array.initialize(param.bins, param.rays);
            blobs.get(param.blobidraw).setDepth(param.depthraw);
            array.setBlobdata(blobs.get(param.blobidraw));
            blobs.get(param.blobidray).setDepth(param.depthray);
            array.setBlobray(blobs.get(param.blobidray));
            array.setGain(maxd);
            array.setOffset(mind);
            data.getArrayList().put(param.blobidraw + "", array);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.parsers.FileParser#getProduct()
     */
    @Override
    public DataContainer getData() {
        return data;
    }

    class Param {
        int rays;
        int bins;
        int depthraw;
        int depthray;
        int blobidraw = -1;
        int blobidray = -1;

        public boolean isValid() {
            if (rays > 0 && bins > 0 && depthraw > 0 && depthray > 0
                    && blobidraw != -1 && blobidray != -1) {
                return true;
            } else
                return false;
        }

    }

    private HashMap<Integer, Param> setParams(File rbfile) {
        FileInputStream fis;
        HashMap<Integer, Param> params = new HashMap<Integer, Param>();
        
        try {
            fis = new FileInputStream(rbfile);
        } catch (FileNotFoundException e2) {
            log.printMsg(
                    "File " + rbfile.getName() + " was not found", Log.TYPE_ERROR, Log.MODE_VERBOSE);
            return params;
        }
        
        XMLStreamReader xml;
        try {
            xml = XMLInputFactory.newInstance().createXMLStreamReader(fis);

//            data = null;
            Param param = null;
            int sliceid = 0;

            while (xml.hasNext()) {

                int rays = 0, bins = 0, depth = 0;
                int blobid = -1;

                int event = xml.next();

                if (event == XMLStreamConstants.END_ELEMENT) {

                    if (xml.getLocalName().matches(VOLUME)) {
                        break;
                    }
                }
                if (event == XMLStreamConstants.START_ELEMENT) {
                    String element = xml.getLocalName();
                    // System.out.println("1: " + element);

                    if (element.matches(SLICE)) {
                        sliceid = -1;
                        param = new Param();
                        for (int i = 0; i < xml.getAttributeCount(); i++) {
                            if (xml.getAttributeLocalName(i).matches("refid")) {

                                try {
                                    sliceid = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                } catch (NumberFormatException e) {
                                    
                                }
                            }
                        }
                        continue;
                    }

                    if (element.matches(RAWDATA) || element.matches(RAYINFO)) {
                        // System.out.println("2: " + type);

                        for (int i = 0; i < xml.getAttributeCount(); i++) {
                            if (xml.getAttributeLocalName(i).matches(BLOBID)) {
                                try {
                                    blobid = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                    // System.out.println("blobid: " + blobid);
                                } catch (NumberFormatException e) {
                                    
                                }
                            } else if (xml.getAttributeLocalName(i).matches(
                                    RAYS)) {
                                try {
                                    rays = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                    // System.out.println("sizeX: " + sizeX);
                                } catch (NumberFormatException e) {
                                   
                                }
                            } else if (xml.getAttributeLocalName(i).matches(
                                    BINS)) {
                                try {
                                    bins = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                    // System.out.println("sizeY: " + sizeY);
                                } catch (NumberFormatException e) {
                                    
                                }
                            } else if (xml.getAttributeLocalName(i).matches(
                                    DEPTH)) {
                                try {
                                    depth = (Integer.parseInt(xml
                                            .getAttributeValue(i)));
                                } catch (NumberFormatException e) {
                                    
                                }
                            }
                        }

                        if (element.matches(RAWDATA)) {
                            param.rays = rays;
                            param.bins = bins;
                            param.depthraw = depth;
                            param.blobidraw = blobid;

                        } else if (element.matches(RAYINFO)) {
                            param.depthray = depth;
                            param.blobidray = blobid;
                        }

                        if (param.isValid() && sliceid != -1) {
                            params.put(sliceid, param);
                        }

                    }

                }
            }

            fis.close();
            xml.close();
        } catch (XMLStreamException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (FactoryConfigurationError e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return params;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.VolumeParser#getVolume()
     */
    @Override
    public PolarData getPolarData() {
        return data;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.VolumeParser#isPolarVolume()
     */
    @Override
    public boolean isPolarVolume() {
        if(data == null)
            return false;
        return true;
    }

}
