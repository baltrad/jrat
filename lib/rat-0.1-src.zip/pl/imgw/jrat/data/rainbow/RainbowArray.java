/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.rainbow;

import pl.imgw.jrat.data.ArrayData;

/**
 * 
 * Range bins are stored in the array’s equivalent X-dimension and azimuth gates
 * in the Y-dimension
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public abstract class RainbowArray extends ArrayData {

    protected double offset = 0;
    protected double gain = 0;

    /**
     * Converts a two byte array to an integer
     * @param b a byte array of length 2
     * @return an int representing the unsigned short
     */
    protected int unsignedShortToInt(byte[] b) {
        int i = 0;
        i |= b[0] & 0xFF;
        i <<= 8;
        i |= b[1] & 0xFF;
        return i;
    }
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.ArrayData#initialize(int, int)
     */
    @Override
    public void initialize(int sizeX, int sizeY) {
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        
    }

    /**
     * @param offset the offset to set
     */
    public void setOffset(double offset) {
        this.offset = offset;
    }


    /**
     * @param gain the gain to set
     */
    public void setGain(double gain) {
        this.gain = gain;
    }
    
    /**
     * @return the offset
     */
    public double getOffset() {
        return offset;
    }

    /**
     * @return the gain
     */
    public double getGain() {
        return gain;
    }
    
    protected double raw2real(int x) {
        return gain * x + offset;
    }

    public void setNoDataValue(double nodata) {
        this.nodata = nodata;
    }

    
    
}
