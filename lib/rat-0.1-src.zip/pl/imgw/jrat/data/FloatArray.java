/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class FloatArray extends ArrayData implements Cloneable {

    private float[][] data;
    private boolean transposed = false;

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.arrays.ArrayData#getSizeX()
     */
    @Override
    public int getSizeX() {
        return (transposed) ? super.getSizeY() : super.getSizeX();
    }
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.arrays.ArrayData#getSizeY()
     */
    @Override
    public int getSizeY() {
        return (transposed) ? super.getSizeX() : super.getSizeY();
    }
    
    public FloatArray() {
    }

    /**
     * @param array
     */
    public FloatArray(float[][] data) {
        if (data != null) {
            this.sizeX = data.length;
            this.sizeY = data[0].length;
            this.data = data;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.ArrayDataContainer#initialize(int, int)
     */
    @Override
    public void initialize(int sizeX, int sizeY) {
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.data = new float[sizeX][sizeY];

    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.ArrayDataContainer#getPoint(int, int)
     */
    @Override
    public short getRawIntPoint(int x, int y) {
        if(transposed) {
            int tmp = x;
            x = y;
            y = tmp;
        }
        if (x < 0 || y < 0 || x >= sizeX || y >= sizeY) {
            throw new OutOfBoundsException();
        }
        return (short) data[x][y];
    }

    /**
     * 
     * @param x
     * @param y
     * @param value
     * @return <b>false</b> if x and y is out of bounds
     */
    public boolean setFloatPoint(int x, int y, float value) {
        if (x < 0 || y < 0 || x >= sizeX || y >= sizeY) {
            return false;
        }
        data[x][y] = value;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.ArrayDataContainer#getBytePoint(int, int)
     */
    @Override
    public byte getRawBytePoint(int x, int y) {
        if(transposed) {
            int tmp = x;
            x = y;
            y = tmp;
        }
        if (x < 0 || y < 0 || x >= sizeX || y >= sizeY) {
            throw new OutOfBoundsException();
        }
        return int2byte((short) data[x][y]);
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.ArrayDataContainer#getDoublePoint(int, int)
     */
    @Override
    public double getPoint(int x, int y) {
        if(transposed) {
            int tmp = x;
            x = y;
            y = tmp;
        }
        if (x < 0 || y < 0 || x >= sizeX || y >= sizeY) {
            // System.out.println(index ++);
            throw new OutOfBoundsException();
        }
        return data[x][y];
    }


    public void setNoDataValue(double nodata) {
        this.nodata = nodata;
    }

    public void multiArrayCopy(float[][] source, float[][] destination) {
        for (int a = 0; a < source.length; a++) {
            System.arraycopy(source[a], 0, destination[a], 0, source[a].length);
        }
    }

    public Object clone() {

        float[][] array = new float[sizeX][sizeY];
        multiArrayCopy(data, array);

        ArrayData dc = new FloatArray(array);

        return dc;
    }
    
    public void transpose() {
        transposed = true;
    }
    
    public boolean isTransposed() {
        return transposed;
    }

}
