/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.parsers;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import pl.imgw.jrat.data.ArrayData;
import pl.imgw.jrat.data.DataContainer;
import pl.imgw.jrat.data.FloatArray;
import pl.imgw.jrat.data.PolarData;
import pl.imgw.jrat.data.UnsignedByteArray;
import pl.imgw.jrat.data.odim.OdimDataContainer;
import pl.imgw.jrat.data.odim.OdimH5CompoImage;
import pl.imgw.jrat.data.odim.OdimH5Volume;
import pl.imgw.util.Log;
import pl.imgw.util.LogManager;
import ch.systemsx.cisd.hdf5.HDF5Factory;
import ch.systemsx.cisd.hdf5.IHDF5Reader;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class OdimH5Parser implements VolumeParser {

    private static Log log = LogManager.getLogger();
    
    public final static String FLOAT_SYMBOL = "FLOAT";
    public final static String INT_SYMBOL = "INTEGER";
    
    private static final String ODIM_CONV = "ODIM_H5";
    private static final String CONVENTIONS = "Conventions";
    
    private OdimDataContainer h5data;
    private IHDF5Reader reader;
    private static final String ROOT = "/";
    private static final String DATA = "data";
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.FileParser#isValid(java.io.File)
     */
    @Override
    public boolean isValid(File file) {

        if(h5data == null)
            parse(file);
        
        try {
            if (((String) h5data.getAttributeValue(ROOT, CONVENTIONS))
                    .contains(ODIM_CONV))
                return true;
            else
                return false;
                
        } catch (Exception e) {
            return false;
        }
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.parsers.FileParser#initialize(java.io.File)
     */
    @Override
    public boolean parse(File file) {
        
        try {
            if (!HDF5Factory.isHDF5File(file))
                return false;
            reader = HDF5Factory.openForReading(file);
            
            if (isPolarVolume())
                h5data = new OdimH5Volume();
            else if (isCompoImage())
                h5data = new OdimH5CompoImage();
            else
                return false;
            
            h5data.setReader(reader);
            
            log.printMsg("OdimH5 file " + file.getName() + " initialized",
                    Log.TYPE_NORMAL, Log.MODE_VERBOSE);
            
        } catch (Exception e) {
//            e.printStackTrace();
            log.printMsg("Initialization of ODIM file: " + file.getName()
                    + " failed", Log.TYPE_ERROR, Log.MODE_VERBOSE);
                    
            return false;
        }

        readDatasets();
        return isValid(file);
    }

    private void readDatasets() {

        HashMap<String, ArrayData> arrayList = new HashMap<String, ArrayData>();
        Set<String> paths = new LinkedHashSet<String>();
        paths.add(ROOT);
        paths = getDataPathSet(paths);
        Iterator<String> i = paths.iterator();
//        int index = 0;
        while (i.hasNext()) {
            
            String path = i.next();
            double nodata = getNodataValue(path);
            
            String type = reader.getDataSetInformation(path).toString();
            if(type.contains(FLOAT_SYMBOL)) {
//                System.out.println(path);
                FloatArray adc = new FloatArray(reader.readFloatMatrix(path));
                adc.setNoDataValue(nodata);
                arrayList.put(path, adc);
//                index++;
            } else if(type.contains(INT_SYMBOL)) {
                UnsignedByteArray adc = new UnsignedByteArray();
                adc.setIntData(reader.readIntMatrix(path));
                adc.setNoDataValue(nodata);
                adc.transpose();
                arrayList.put(path, adc);
//                index++;
            }
            
        }
        h5data.setArrayList(arrayList);
        
    }

    /**
     * @param path
     * @return
     */
    private double getNodataValue(String path) {
        
        String nodataPath = "";
        if (((String) h5data.getAttributeValue("/what", "object"))
                .matches("PVOL")
                || ((String) h5data.getAttributeValue("/what", "object"))
                        .matches("SCAN")) {
            nodataPath = path.replace("data/", "what/");
        } else {
            nodataPath = path.replace("data1/data/", "what/");
        }
        double nodata = (Double) h5data.getAttributeValue(nodataPath, "nodata");
        
        return nodata;
    }

    private Set<String> getDataPathSet(Set<String> paths) {
        Iterator<String> itr = paths.iterator();
        while (itr.hasNext()) {
            String path = itr.next();
            if (!reader.exists(path))
                paths.remove(path);
            if (reader.isDataSet(path))
                continue;
            paths.remove(path);
            List<String> list = reader.getAllGroupMembers(path);
            Iterator<String> i = list.iterator();
            while (i.hasNext()) {
                String name = i.next();
                if (name.contains(DATA)) {
                    paths.add(path + name + "/");
                    getDataPathSet(paths);
                }
            }
        }
        return paths;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.parsers.FileParser#getProduct()
     */
    @Override
    public DataContainer getData() {
        return h5data;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.VolumeParser#getVolume()
     */
    @Override
    public PolarData getPolarData() {
        if(h5data instanceof OdimH5Volume)
            return (PolarData) h5data;
        return null;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.VolumeParser#isPolarVolume()
     */
    @Override
    public boolean isPolarVolume() {
        try {
            if (reader.getStringAttribute("/what", "object").matches("PVOL")
                    || reader.getStringAttribute("/what", "object").matches("SCAN"))
                return true;
        } catch (Exception e) {
            
        }
        return false;
    }

    private boolean isCompoImage() {
        try {
            if (reader.getStringAttribute("/what", "object").matches("COMP")) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }

}
