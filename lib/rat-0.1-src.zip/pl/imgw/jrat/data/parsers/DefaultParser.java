/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.parsers;

import java.io.File;

import pl.imgw.jrat.data.DataContainer;
import pl.imgw.jrat.data.PolarData;
import pl.imgw.jrat.data.rainbow.RainbowImageParser;
import pl.imgw.jrat.data.rainbow.RainbowVolumeParser;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class DefaultParser implements FileParser, VolumeParser {

	private RainbowVolumeParser rbvol;
	private RainbowImageParser rbimg;
	private OdimH5Parser odim;
//	private WZFileParser wz;
	private WZStatsParser wzstat;
	private IntArrayParser intarray;

	private final int HDF = 0;
	private final int RBI = 1;
	private final int RBV = 2;
//	private final int WZ = 3;
	private final int WZSTAT = 4;
	private final int INTARRAY = 5;
	private int format = -1;

	/*
	 * (non-Javadoc)
	 * 
	 * @see pl.imgw.jrat.data.parsers.FileParser#isValid(java.io.File)
	 */
	@Override
	public boolean isValid(File file) {
		
	    initializeParsers();
	    
		if (odim.isValid(file)) {
			format = HDF;
			return true;
		}
		if (rbvol.isValid(file)) {
			format = RBV;
			return true;
		}
		
		if (rbimg.isValid(file)) {
			format = RBI;
			return true;
		}
		/*
		if (wz.isValid(file)) {
			format = WZ;
			return true;
		}
		*/
		if (wzstat.isValid(file)) {
			format = WZSTAT;
			return true;
		}
		/*
		 * reading int array, additional
		 */
		if (intarray.isValid(file)) {
			format = INTARRAY;
			return true;
		}

		return false;
	}

	private void initializeParsers() {
	    rbvol = new RainbowVolumeParser();
	    rbimg = new RainbowImageParser();
	    odim = new OdimH5Parser();
//	    wz = new WZFileParser();
	    wzstat = new WZStatsParser();
	    intarray = new IntArrayParser();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see pl.imgw.jrat.data.parsers.FileParser#initialize(java.io.File)
	 */
	@Override
	public boolean parse(File file) {

	    initializeParsers();
	    
        if (odim.isValid(file)) {
            format = HDF;
            return odim.parse(file);
        }
		if (rbvol.isValid(file)) {
			format = RBV;
			return rbvol.parse(file);
		}
		if (rbimg.isValid(file)) {
			format = RBI;
			return rbimg.parse(file);
		}
		/*
		if (wz.isValid(file)) {
			format = WZ;
			return wz.parse(file);
		}
		 */
		if (wzstat.isValid(file)) {
			format = WZSTAT;
			return wzstat.parse(file);
		}
		if (intarray.isValid(file)) {
			format = INTARRAY;
			return intarray.parse(file);
		}

		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see pl.imgw.jrat.data.parsers.FileParser#getProduct()
	 */
	@Override
	public DataContainer getData() {
		if (format == HDF)
			return odim.getData();
		if (format == RBV)
			return rbvol.getData();
		if (format == RBI)
			return rbimg.getData();
		/*
		if (format == WZ)
			return wz.getData();
		 */
		if (format == WZSTAT)
			return wzstat.getData();
		if (format == INTARRAY)
			return intarray.getData();
		return null;
	}

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.VolumeParser#getVolume()
     */
    @Override
    public PolarData getPolarData() {
        
        if (format == RBV) {
            return rbvol.getPolarData();
        }
        if (format == HDF) {
            return odim.getPolarData();
        }
        
        return null;
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.parsers.VolumeParser#isPolarVolume()
     */
    @Override
    public boolean isPolarVolume() {
        
        if (format == RBV) {
            return rbvol.isPolarVolume();
        }
        if (format == HDF) {
            return odim.isPolarVolume();
        }
        
        return false;
    }
    
}
