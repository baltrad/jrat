/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.parsers;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class FileParsingException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = -9049524313310908409L;

    /**
     * @param string
     */
    public FileParsingException(String string) {
        super(string);
    }

}
