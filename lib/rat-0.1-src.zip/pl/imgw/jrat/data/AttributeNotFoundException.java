/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class AttributeNotFoundException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = -7631932342201080475L;

    /**
     * 
     */
    public AttributeNotFoundException(String msg) {
     super(msg);
    }
    
}
