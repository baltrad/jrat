/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data.odim;

import java.awt.geom.Point2D;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import pl.imgw.jrat.data.PolarData;
import pl.imgw.jrat.data.ScanContainer;
import pl.imgw.jrat.data.UnsignedByteArray;
import pl.imgw.util.Log;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class OdimH5Volume extends OdimDataContainer implements PolarData {

    private Map<Double, ScanContainer> scans = new HashMap<Double, ScanContainer>();

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getLon()
     */
    @Override
    public Double getLon() {

        return (Double) getAttributeValue("/where", "lon");
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getLat()
     */
    @Override
    public Double getLat() {

        return (Double) getAttributeValue("/where", "lat");
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getHeight()
     */
    @Override
    public Double getHeight() {
        return (Double) getAttributeValue("/where", "height");
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getWavelength()
     */
    @Override
    public Double getWavelength() {
        
        return (Double) getAttributeValue("/how", "wavelength");
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getPulsewidth()
     */
    @Override
    public Double getPulsewidth() {
        return (Double) getAttributeValue("/how", "pulsewidth");
    }
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getBeamwidth()
     */
    @Override
    public Double getBeamwidth() {
        return (Double) getAttributeValue("/how", "beamwidth");
    }
    

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstH()
     */
    @Override
    public Double getRadConstH() {
        return (Double) getAttributeValue("/how", "radconstH");
    }

    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.containers.VolumeContainer#getRadConstV()
     */
    @Override
    public Double getRadConstV() {
        return (Double) getAttributeValue("/how", "radconstV");
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getSiteName()
     */
    @Override
    public String getSiteName() {
        
        String source = (String) getAttributeValue("/what", "source");

        String[] src1 = source.split(",");
        String tmp = "";

        for (String s : src1) {
            if (s.startsWith("PLC:")) {
                tmp = s.substring("PLC:".length());
                break;
            } else if (s.startsWith("WMO:")) {
                tmp = s.substring("WMO:".length());
            } else if (s.startsWith("RAD:")) {
                tmp = s.substring("RAD:".length());
            }
        }

        return tmp;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getScan(double)
     */
    @Override
    public ScanContainer getScan(final double elevation) {
        
        if(scans.containsKey(elevation))
            return scans.get(elevation);

        if (getDatasetByElevation(elevation) == null) {
            return null;
        }

        ScanContainer scan = new ScanContainer() {

            String dataset = "/" + getDatasetByElevation(elevation);

            @Override
            public Date getStartTime() {
                try {
                    String time = (String) getAttributeValue(dataset
                            + "/what", "starttime");
                    String date = (String) getAttributeValue(dataset
                            + "/what", "startdate");
                    return formatSecondPrecision.parse(date + time);
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            public double getRScale() {
                return (Double) getAttributeValue(dataset + "/where",
                        "rscale");
            }

            @Override
            public int getNRays() {
                return (Integer) getAttributeValue(dataset + "/where",
                        "nrays");
            }

            @Override
            public int getNBins() {
                return (Integer) getAttributeValue(dataset + "/where",
                        "nbins");
            }

            @Override
            public double getElevation() {
                return elevation;
            }

            @Override
            public UnsignedByteArray getArray() {

                UnsignedByteArray array = (UnsignedByteArray) OdimH5Volume.this.getArray(dataset + "/data1/data");
                array.setGain((Double) getAttributeValue(dataset
                        + "/data1/what", "gain"));
                array.setOffset((Double) getAttributeValue(dataset
                        + "/data1/what", "offset"));
                return array;
            }

            @Override
            public Point2D.Double getCoordinates() {
                return new Point2D.Double(getLon(), getLat());
            }

            @Override
            public double getRPM() {
                return (Double) getAttributeValue(dataset + "/how", "rpm");
            }

            @Override
            public double getOffset() {
                Double o = (Double) getAttributeValue(dataset
                        + "/data1/what", "offset");

                return (o == null) ? 0 : o;
            }

            @Override
            public double getGain() {
                Double g = (Double) getAttributeValue(dataset
                        + "/data1/what", "gain");
                return (g == null) ? 1 : g;
            }

            @Override
            public double getNodata() {
                return (Double) getAttributeValue(dataset + "/data1/what",
                        "nodata");
            }

            @Override
            public double getUndetect() {
                return (Double) getAttributeValue(dataset + "/data1/what",
                        "undetect");
            }
        };
        scans.put(elevation, scan);
        return scan;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getTime()
     */
    @Override
    public Date getTime() {
        String time = (String) getAttributeValue("/what", "time");
        String date = (String) getAttributeValue("/what", "date");
        try {
            return formatMinutePrecision.parse(date
                    + time.substring(0, time.length() - 2));
        } catch (ParseException e) {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getTimeSec()
     */
    @Override
    public Date getTimeSec() {
        String time = (String) getAttributeValue("/what", "time");
        String date = (String) getAttributeValue("/what", "date");
        try {
            return formatSecondPrecision.parse(date + time);
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * 
     * Receive name of the group which contains data from given elevation
     * 
     * @param elevation
     *            in degrees (e.g. 0.5, 3.4)
     * @return empty string if not find
     */
    private String getDatasetByElevation(double elevation) {
        List<String> attrs = reader.getAllGroupMembers("/");
        Iterator<String> i = attrs.iterator();
        while (i.hasNext()) {
            String group = i.next();
            if (group.contains("dataset")) {
                double ele = (Double) getAttributeValue("/" + group
                        + "/where", "elangle");
                if (ele == elevation)
                    return group;
            }
        }
        log.printMsg(
                "Elevation " + elevation + " not found in " + getVolId(),
                Log.TYPE_WARNING, Log.MODE_VERBOSE);

        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.data.VolumeContainer#getVolId()
     */
    @Override
    public String getVolId() {
        String id = "'HDF5 vol ";
        id += getSiteName();
        id += " ";
        id += formatMinutePrecision.format(getTime());
        id += "'";
        return id;
    }

    
    private double getElevation(String datasetName) {

        String[] parts = datasetName.split("/");
        String path = "/";
        for (String part : parts) {
            if (part.startsWith("dataset")) {
                path += part + "/where";
                return (Double) getAttributeValue(path, "elangle");
            }
        }
        return 0;
    }
    
    /* (non-Javadoc)
     * @see pl.imgw.jrat.data.VolumeContainer#getAllScans()
     */
    @Override
    public List<ScanContainer> getAllScans() {
//        List<ScanContainer> scans = new ArrayList<ScanContainer>();
        for(String eleStr : getArrayList().keySet()) {
            double ele = getElevation(eleStr);
            getScan(ele);
        }
        return new ArrayList<ScanContainer>(scans.values());
    }


}
