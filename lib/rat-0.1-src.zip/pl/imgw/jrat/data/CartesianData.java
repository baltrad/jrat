/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.jrat.data;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public interface CartesianData {

    public SimpleDateFormat formatSecondPrecision = new SimpleDateFormat("yyyyMMddHHmmss");
    public SimpleDateFormat formatMinutePrecision = new SimpleDateFormat("yyyyMMddHHmm");
    
    /**
     * @return
     */
    Date getTime();

    /**
     * @return
     */
    int getXSize();

    /**
     * @return
     */
    int getYSize();

    /**
     * @return
     */
    String getProjDef();

    /**
     * @return
     */
    double getXScale();

    /**
     * @return
     */
    double getYScale();

    /**
     * @return
     */
    String getSourceName();

    /**
     * @return
     */
    ArrayData getData();

}
