/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public abstract class Log {

    public static final int MODE_VERBOSE = 3;
    public static final int MODE_NORMAL = 2;
    public static final int MODE_SILENT = 1;
    private static final int MODE_DISABLE = 0;
    
    public static final int TYPE_NORMAL = 0;
    public static final int TYPE_WARNING = 3;
    public static final int TYPE_ERROR = 6;
    
    protected int setMode;
    /**
     * 
     * Print message
     * 
     * @param msg
     * 
     */
    public abstract void printMsg(String msg);

    /**
     * 
     * Print message
     * 
     * @param msg
     * 
     * @param type
     *            specify type of message
     * 
     */
    public abstract void printMsg(String msg, int type);

    /**
     * 
     * Print message
     * 
     * @param msg
     * 
     * @param type
     *            specify type of message
     * 
     * @param mode
     *            specify in which mode (at least) should the message be shown
     * 
     */
    public abstract void printMsg(String msg, int type, int mode);

    
    protected void setMode(int mode) {
        this.setMode = mode;
    }
    
    private int tmpMode;
    
    protected void disable() {
        tmpMode = setMode;
        this.setMode = MODE_DISABLE;
    }
    
    protected void enable() {
        this.setMode = tmpMode;
    }
}