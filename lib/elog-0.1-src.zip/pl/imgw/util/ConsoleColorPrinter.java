/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

import org.apache.commons.lang.SystemUtils;

/**
 * 
 * In UNIX systems printing messages in color
 * <p>
 * NORMAL = blue
 * <p>
 * WARNING = yellow
 * <p>
 * ERROR = red
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class ConsoleColorPrinter extends ConsolePrinter {

    /**
     * @param setMode
     */
    public ConsoleColorPrinter(int setMode) {
        super(setMode);
        // TODO Auto-generated constructor stub
    }

    private static final String ANSI_RESET = "\u001B[0m";
//    private static final String ANSI_BLACK = "\u001B[30m";
    private static final String ANSI_RED = "\u001B[31m";
//    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_BLUE = "\u001B[34m";

    /* (non-Javadoc)
     * @see pl.imgw.util.Log#printMsg(java.lang.String, int, int)
     */
    @Override
    public void printMsg(String msg, int type, int mode) {
        StringBuilder colorMsg = new StringBuilder();

        if (SystemUtils.IS_OS_UNIX) {
            if (type == TYPE_ERROR) {
                colorMsg.append(ANSI_RED);
            } else if (type == TYPE_WARNING) {
                colorMsg.append(ANSI_YELLOW);
            } else if (type == TYPE_NORMAL) {
                colorMsg.append(ANSI_BLUE);
            }
        }

        colorMsg.append(msg);
        if (SystemUtils.IS_OS_UNIX) {
            colorMsg.append(ANSI_RESET);
        }
        super.printMsg(colorMsg.toString(), type, mode);
    }

}
