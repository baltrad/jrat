/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

import java.io.File;

/**
 * 
 * Log handler
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public interface LogFile {

    /**
     * General logs handler. File will be save in the path set by the other
     * method.
     * 
     * @param msg
     */
    public void saveGeneralLogs(String msg);

    /**
     * Recent file logs handler. File will be save in the path set by the other
     * method.
     * 
     * @param msg
     */
    public void saveRecentFileLogs(File file);

    /**
     * Error logs handler. File will be save in the path set by the other
     * method.
     * 
     * @param className
     * @param msg
     */
    public void saveErrorLogs(String className, String msg);

    public File getRecentFolder();

    public File getErrorFolder();

    public File getGeneralFolder();
    
}
