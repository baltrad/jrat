/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

import java.io.File;

/**
 * 
 * Log handler
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public interface LogFile {

    /**
     * General logs handler. File will be save in the path set by the other
     * method.
     * 
     * @param msg
     */
    public void saveGeneralLogs(String msg);

    /**
     * Recent file logs handler. File will be save in the path set by the other
     * method.
     * 
     * @param msg
     */
    public void saveRecentFileLogs(File file);

    /**
     * Error logs handler. File will be save in the path set by the other
     * method.
     * 
     * @param className
     * @param msg
     */
    public void saveErrorLogs(String className, String msg);

    public File getRecentFolder();

    public File getErrorFolder();

    public File getGeneralFolder();

    /**
     * @param errorFreq
     *            how often a new error log file should be created, in hours
     *            (1-24), for other values new file will be created daily
     */
	public void setErrorFreq(int errorFreq);

    /**
     * @param generalFreq
     *            how often a new general log file should be created, in hours
     *            (1-24), for other values new file will be created daily
     */
 	public void setGeneralFreq(int generalFreq);

    /**
     * @param recentFreq
     *            how often a new recent log file should be created, in hours
     *            (1-24), for other values new file will be created daily
     */
 	public void setRecentFreq(int recentFreq);
}
