/**
 * (C) 2012 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class ConsoleProgressBar {

    private int barSize = 1;
    private double factor = 1;
    private int maxValue = 1;
    private String startMsg = "";
    private String doneMsg = "";
    private int progress = 0;
    private boolean show = false;
    private boolean progressComplete = true;

    private ConsoleProgressBar() {
        ;
    }

    private static ConsoleProgressBar cpb = new ConsoleProgressBar();

    protected static ConsoleProgressBar getProgressBar() {
        return cpb;
    }

    /**
     * 
     * Starts new progress bar.
     * 
     * @param barSize
     *            width of progress bar in console
     * @param maxValue
     *            reaching this value progress bar will show 100%
     * @param show
     *            use false if you don't want to display progress bar in console
     * @param startMsg
     *            message printed in front of progress bar
     */
    public void initialize(int barSize, int maxValue, String startmsg) {
        initialize(barSize, maxValue, startmsg, "done");
    }

    /**
     * 
     * Starts new progress bar.
     * 
     * @param barSize
     *            width of progress bar in console
     * @param maxValue
     *            reaching this value progress bar will show 100%
     * @param show
     *            use false if you don't want to display progress bar in console
     * @param startMsg
     *            message printed in front of progress bar
     *            
     * @param doneMsg
     */
    public void initialize(int barSize, int maxValue, String startMsg, String doneMsg) {
        
        if(progress > 0) {
            complete();
        }
        progressComplete = false;
        disableLogger();
        this.startMsg = startMsg;
        this.doneMsg = doneMsg;
        this.barSize = barSize;
        factor = (double) barSize / (double) maxValue;
        this.maxValue = maxValue;
        evaluate();
    }
    
    /**
     * 
     * Starts new progress bar.
     * 
     * @param barSize
     *            width of progress bar in console
     * @param maxValue
     *            reaching this value progress bar will show 100%
     * @param show
     *            use false if you don't want to display progress bar in console
     */
    public void initialize(int barSize, int maxValue) {
        initialize(barSize, maxValue, "", "");

    }

    private void resetProgress() {
        progress = 0;
    }

    /**
     * Update progress bar, the progress will show (<code>value</code> /
     * <code>maxValue</code>) * 100%
     * 
     * @param value
     */
    public void evaluate() {
        if (show()) {
            String bars = getProgress(progress++);
            System.out.print(startMsg + "\t\t|" + bars + "|\r");
        }
        if (hasReachTheEnd()) {
            complete(doneMsg);
            resetProgress();
        }
    }

    

    /**
     * Complete the bar and print done message given on initialization
     */
    public void complete() {
        complete(doneMsg);
    }
    
    /**
     * Ends the progress bar and print the end message
     */
    public void complete(String endMsg) {
        if (show()) {
            String progress = getProgress(maxValue);
            System.out.print(startMsg + "\tdone\t|" + progress + "| " + endMsg);
            System.out.print("\n");
        }
        progressComplete = true;
        enableLogger();
        resetProgress();
    }

    private String getProgress(int value) {
        int prog = (int) (factor * value);

        String progress = "";
        for (int i = 0; i < prog; i++)
            progress += "=";
        for (int i = 0; i < barSize - prog; i++)
            progress += " ";
        return progress;
    }

    /**
     * When show console
     * 
     * @param mode
     */
    public void enable() {
        show = true;
    }
    
    /**
     * When show console
     * 
     * @param mode
     */
    public void disable() {
        show = false;
    }

    private boolean hasReachTheEnd() {
        return progress >= maxValue;
    }
    
    private boolean show() {
        return show && !progressComplete;
    }
    
    private void enableLogger() {
        LogManager.getLogger().enable();
    }
    
    private void disableLogger() {
        LogManager.getLogger().disable();
    }
}
