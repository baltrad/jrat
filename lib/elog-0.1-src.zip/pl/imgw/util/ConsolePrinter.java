/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class ConsolePrinter extends Log {

    
    protected String msgFormat = "[dd/MM/yy HH:mm:ss] ";
    protected SimpleDateFormat msgDate = new SimpleDateFormat(msgFormat);
    protected Date date = new Date();
    
    /**
     * 
     */
    public ConsolePrinter(int mode) {
        this.setMode = mode;
    }
    
    /* (non-Javadoc)
     * @see pl.imgw.util.Log#printMsg(java.lang.String)
     */
    @Override
    public void printMsg(String msg) {
        printMsg(msg, TYPE_NORMAL, MODE_VERBOSE);
        
    }
    
    /* (non-Javadoc)
     * @see pl.imgw.util.Log#printMsg(java.lang.String, int)
     */
    @Override
    public void printMsg(String msg, int type) {
        printMsg(msg, type, MODE_VERBOSE);

    }

    @Override
    public void printMsg(String msg, int type, int mode) {
        if (mode <= setMode) {
            date.setTime(System.currentTimeMillis());
            System.out.println(msgDate.format(date) + msg);
        }
    }

    /* (non-Javadoc)
     * @see pl.imgw.util.Log#setMode(int)
     */
    @Override
    public void setMode(int mode) {
        setMode = mode;
        
    }
    
}
