/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class LogFileHandler implements LogFile {

    private static final String LOG_FILE_EXT = ".log";
    private static final String TYPE_RECENT = "rec";
    private static final String TYPE_ERROR = "err";
    private static final String TYPE_GENERAL = "gen";

    private String msgFormat = "[dd/MM/yy HH:mm:ss] ";
    private SimpleDateFormat msgDate = new SimpleDateFormat(msgFormat);

    private String fileFormat = "yyyyMMddHHmm";
    private SimpleDateFormat fileDate = new SimpleDateFormat(fileFormat);
    private Date date = new Date();

    private File errorFolder = null;
    private File errorFile = new File("");
    
    private File generalFolder = null;
    private File generalFile = new File("");
    
    private File recentFolder = null;
    private File recentFile = new File("");

    private int errorFreq = 0;
    private int generalFreq = 0;
    private int recentFreq = 0;
    
    public LogFileHandler() {
        this(new File("."));
    }

    public LogFileHandler(File path) {
        setRecentLogs(new File(path, TYPE_RECENT));
        setErrorLogs(new File(path, TYPE_ERROR));
        setGeneralLogs(new File(path, TYPE_GENERAL));
    }
    
    private void setGeneralLogs(File path) {
        path.mkdirs();
        this.generalFolder = path;

    }


    private void setRecentLogs(File path) {
        path.mkdirs();
        this.recentFolder = path;

    }


    private void setErrorLogs(File path) {
        path.mkdirs();
        this.errorFolder = path;

    }

	@Override
    public void setErrorFreq(int errorFreq) {
        this.errorFreq = errorFreq;
    }

	@Override
   	public void setGeneralFreq(int generalFreq) {
        this.generalFreq = generalFreq;
    }

	@Override
    public void setRecentFreq(int recentFreq) {
        this.recentFreq = recentFreq;
    }
    
    /**
     * @return the errorFolder
     */
    @Override
    public File getErrorFolder() {
        return errorFolder;
    }

    /**
     * @return the generalFolder
     */
    @Override
    public File getGeneralFolder() {
        return generalFolder;
    }

    /**
     * @return the recentFolder
     */
    @Override
    public File getRecentFolder() {
        return recentFolder;
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.output.Logging#saveGeneralLogs(java.lang.String)
     */
    @Override
    public void saveGeneralLogs(String msg) {
        String filename = getFileName(generalFreq, TYPE_GENERAL);
        if (!generalFile.getName().contains(filename))
            generalFile = new File(generalFolder, filename);

        date.setTime(System.currentTimeMillis());
        saveLineToFile(generalFile, msgDate.format(date) + msg);
    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.output.Logging#saveRecantFileLogs(java.io.File)
     */
    @Override
    public void saveRecentFileLogs(File file) {
        String folder = file.getAbsolutePath();
        String msg = "New file: '" + file.getName() + "' in " + folder;

        String filename = getFileName(recentFreq, TYPE_RECENT);
        if (!recentFile.getName().contains(filename))
            recentFile = new File(recentFolder, filename);

        date.setTime(System.currentTimeMillis());
        saveLineToFile(recentFile, msgDate.format(date) + msg);

    }

    /*
     * (non-Javadoc)
     * 
     * @see pl.imgw.jrat.output.Logging#saveErrorLogs(java.lang.String,
     * java.lang.String)
     */
    @Override
    public void saveErrorLogs(String className, String msg) {

        String filename = getFileName(errorFreq, TYPE_ERROR);
        if (!errorFile.getName().contains(filename))
            errorFile = new File(errorFolder, filename);

        date.setTime(System.currentTimeMillis());
        String line = msgDate.format(date) + "[" + className + "]: " + msg;
        saveLineToFile(errorFile, line);

    }
    
    /**
     * 
     * Save class name and exception localized message to error log file
     * 
     * @param obj
     * @param e
     */
    public void saveErrorLogs(Object obj, Exception e) {
        saveErrorLogs(obj.getClass().getName(), e.getLocalizedMessage());

    }
    
    /**
     * Helping method
     * 
     * @param file
     * @param line
     */
    private void saveLineToFile(File file, String line) {
        PrintWriter pw = null;
        synchronized (file) {
            try {
                if (!file.exists())
                    file.createNewFile();
                pw = new PrintWriter(new FileOutputStream(file, true), true);
                pw.println(line);
            } catch (FileNotFoundException e) {
//            logs.printMsg("Log file " + file.getName() + " is missing" + "\n"
//                    + e.getMessage(), 3);
            } catch (IOException e) {
//            logs.printMsg(
//                    "Cannot create log file in path " + file.getAbsolutePath()
//                            + "\n" + e.getMessage(), 3);

            } finally {
                if (pw != null)
                    pw.close();
            }
        }
    }

    
    private String getFileName(int frequency, String type) {
        if (frequency < 1 || frequency > 24)
            frequency = 24;
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        hour = (hour / frequency) * frequency;
//FIXME that only occurs in a day e.g. for frequency == 5; hours can be 0, 5, 10, 15, 20 and next time is in 4 not 5 hours!!!
        cal.set(Calendar.HOUR_OF_DAY, hour);
        return fileDate.format(cal.getTime()) + type + LOG_FILE_EXT;
    }

}
