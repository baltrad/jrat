/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

/**
 *
 *  /Class description/
 *
 *
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class ProgressBarException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = -430493998649516843L;

    /**
     * 
     */
    public ProgressBarException(String msg) {
        super(msg);
    }
    
}
