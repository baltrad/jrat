/**
 * (C) 2013 INSTITUT OF METEOROLOGY AND WATER MANAGEMENT
 */
package pl.imgw.util;

import java.io.File;

/**
 * 
 * /Class description/
 * 
 * 
 * @author <a href="mailto:lukasz.wojtas@imgw.pl">Lukasz Wojtas</a>
 * 
 */
public class LogManager {

    private static LogManager manager = new LogManager();

    protected int mode = Log.MODE_NORMAL;

    private Log log = new ConsoleColorPrinter(mode);
    private LogFile logFile = new LogFileHandler();

    /**
     * Receives singleton of LogManager
     * 
     * @return
     */
    public static LogManager getInstance() {
        return manager;
    }

    public static Log getLogger() {
        return manager.log;
    }
    
    public static ConsoleProgressBar getProgBar() {
        return ConsoleProgressBar.getProgressBar();
    }

    public static LogFile getFileLogger() {
        return manager.logFile;
    }

    public void setLogger(Log log) {
        this.log = log;
    }

    /**
     * 
     * @param mode
     * @throws ProgressBarException
     */
    public void enableProgressBar(int mode) throws ProgressBarException {
        if (this.mode == mode)
            enableProgressBar();
    }

    /**
     * 
     * @throws ProgressBarException
     */
    public void enableProgressBar() throws ProgressBarException {
        if (consoleProgressBarEnable)
            throw new ProgressBarException(
                    "Console progress bar is already enable");
        consoleProgressBarEnable = true;
        ConsoleProgressBar.getProgressBar().enable();
        // log.disable();

    }

    private boolean consoleProgressBarEnable = false;

    public void disableProgressBar() throws ProgressBarException {
        if (consoleProgressBarEnable)
            throw new ProgressBarException(
                    "Console progress bar is already disable");
        // log.enable();
        ConsoleProgressBar.getProgressBar().disable();
    }

    /**
     * setting default log file path
     * 
     * @param path
     */
    public void setLogFile(File path) {
        logFile = new LogFileHandler(path);
    }

    /**
     * setting default file logger
     * 
     * @param logFile
     */
    public void setFileLogger(LogFile logFile) {
        this.logFile = logFile;
    }

    /**
     * 
     * @param mode
     * @throws ProgressBarException
     *             Cannot change mode when console progress bar is enable
     */

    public void setLogMode(int mode) {
//        if (consoleProgressBarEnable)
//            throw new ProgressBarException(
//                    "Cannot change mode when console progress bar is enable");
        log.setMode(mode);
        this.mode = mode;
    }

}
